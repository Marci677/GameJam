﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuScript : MonoBehaviour {

    
    

    public void FadeGame()
    {
        Invoke("PlayGame", .8f);
       
    }

    public void FadeMenu()
    {
        Invoke("PlayMenu", .8f);

    }

    public void FadeOptions()
    {
        Invoke("PlayOptions", .8f);

    }

    public void FadeAbout()
    {
        Invoke("PlayAbout", .8f);

    }

    public void FadeQuit()
    {
        Invoke("QuitGame", .5f);

    }

    public void PlayGame()
    {
        SceneManager.LoadScene("Game");
    }

    public void PlayMenu()
    {
        SceneManager.LoadScene("Menu");
    }

    public void PlayOptions()
    {
        SceneManager.LoadScene("Options");
    }

    public void PlayAbout()
    {
        SceneManager.LoadScene("About");
    }



    public void QuitGame()
    {
        Debug.Log("QUIT!");
        Application.Quit();
    }

}
